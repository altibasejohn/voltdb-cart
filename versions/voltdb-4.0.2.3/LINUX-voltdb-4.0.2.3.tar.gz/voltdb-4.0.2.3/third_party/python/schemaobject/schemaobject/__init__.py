#!/usr/bin/python
__author__ = 'Mitch Matuson'
__copyright__ = "Copyright 2009-2010 Mitch Matuson"
__version__ = "0.5.3"
__license__ = "Apache 2.0"

#shortcut to SchemaObject()
from schemaobject.schema import SchemaObject
